/* eslint-disable react/jsx-key */
import { useState, useEffect, useContext } from "react";
import { UserContext } from "../userContext";
import axios from "axios";
import { useLoaderData, useParams } from "react-router-dom";
import {
  List,
  ListItem,
  Card,
  CardHeader,
  Typography,
} from "@material-tailwind/react";

const Summary = () => {
  const { sid } = useParams();
  const sessionData = useLoaderData();
  const [data, setData] = useState([]);
  const { user } = useContext(UserContext);
  useEffect(() => {
    const fetchData = async () => {
      if (user) {
        try {
          const response = await axios.get(`/response/get/${Number(sid)}`, {
            withCredentials: true,
          });
          //   console.log("These are the results: " + response.data);
          setData(response.data);
          //   const qResponse = await axios.get(
          //     `/questions/getQuestions/${user.username}`,
          //     {
          //       withCredentials: true,
          //     }
          //   );
          //   setSessionId(qResponse.data.session.id);
        } catch (error) {
          console.error(
            "Error fetching data: ",
            error.response || error.message
          );
        }
      } else {
        console.error("User not logged in");
      }
    };

    fetchData();
  }, [user]);

  return (
    <div className="min-h-screen">
      <Typography className="text-center text-2xl font-medium font-Outfit mt-8">
        Summary for Session ID: {sid}
      </Typography>
      <div className="w-full flex justify-center py-10">
        <Card
          variant="gradient"
          className="bg-blue-gray-900 h-auto w-full rounded-xl mx-10 p-2"
        >
          <CardHeader
            floated="false"
            className="grid grid-cols-6 items-center bg-transparent shadow-none mx-5"
          >
            <Typography className="text-blue-gray-50 font-Outfit font-normal text-xl">
              Sr. No.
            </Typography>
            <Typography className="text-blue-gray-50 font-Outfit font-normal text-xl">
              Question
            </Typography>
            <Typography className="text-blue-gray-50 font-Outfit font-normal text-xl">
              Audio Emotions
            </Typography>
            <Typography className="text-blue-gray-50 font-Outfit font-normal text-xl">
              Facial Emotions
            </Typography>
            <Typography className="text-blue-gray-50 font-Outfit font-normal text-xl">
              Textual Emotions
            </Typography>
            <Typography className="text-blue-gray-50 font-Outfit font-normal text-xl">
              Sentiment Score
            </Typography>
          </CardHeader>
          <hr className="mx-5 mt-2" />
          <List>
            {data.map((d, index) => (
              <ListItem
                key={index}
                className="grid grid-cols-6 items-center text-center text-white"
              >
                <div>{index + 1}</div>
                <div>{d.question}</div>
                <div>{d.audioEmotion}</div>
                <div>{d.facialEmotions}</div>
                <div>{d.textEmotion}</div>
                <div>{d.sentimentScore}</div>
              </ListItem>
            ))}
          </List>
        </Card>
      </div>
    </div>
  );
};

export default Summary;
